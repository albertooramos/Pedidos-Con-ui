package com.example.pedidos;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import static com.example.pedidos.HourActivity.DIA;
import static com.example.pedidos.HourActivity.HORA;
import static com.example.pedidos.HourActivity.MODO;
import static com.example.pedidos.MainActivity.CORTADO;
import static com.example.pedidos.MainActivity.LECHE;
import static com.example.pedidos.MainActivity.SOLO;

public class SendActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private int cortado;
    private int solo;
    private int leche;
    private String dia;
    private String hora;
    private EditText nameEdit;
    private EditText addressEdit;
    private EditText phoneEdit;
    private String modo;
    private String tipoTelefono;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send);

        nameEdit = findViewById(R.id.name);
        addressEdit = findViewById(R.id.address);
        phoneEdit = findViewById(R.id.phone);

        Toolbar toolbar = findViewById(R.id.toolbar_send);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        cortado = intent.getIntExtra(CORTADO, 0);
        solo = intent.getIntExtra(SOLO, 0);
        leche = intent.getIntExtra(LECHE, 0);
        hora = intent.getStringExtra(HORA);
        dia = intent.getStringExtra(DIA);
        modo = intent.getStringExtra(MODO);


        String[] arraySpinner = new String[]{
                "Casa", "Trabajo", "Móvil", "Otro"
        };
        Spinner s = (Spinner) findViewById(R.id.spinner2);
        s.setOnItemSelectedListener(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_send, menu);
        return true;
    }

    public void confirmar(MenuItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.dialog_message)
                .setPositiveButton(R.string.yes, (dialog, id) -> sendEmail())
                .setNegativeButton(R.string.no, (dialog, id) -> showToast())
                .create()
                .show();
    }

    private void showToast() {
        Toast.makeText(this, R.string.revisar, Toast.LENGTH_LONG).show();
    }

    private void sendEmail() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        String name = nameEdit.getText().toString();
        String address = addressEdit.getText().toString();
        String phone = phoneEdit.getText().toString();
        String subject = String.format("Pedido de %s", name);
        String body = String.format(
                "Mi pedido es\n" +
                        "%d cafes con leche\n" +
                        "%d cafes solos\n" +
                        "%d cafes cortados\n" +
                        "la fecha de entrega es %s\n" +
                        "la hora de entrega es %s\n" +
                        "modo de entrega: es %s\n" +
                        "Dirección: %s\n" +
                        "Número de teléfono: %s(%s)",

                leche, solo, cortado, dia, hora, modo, address, phone,tipoTelefono);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_EMAIL, "pedidos@mitienda.com");
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, body);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        tipoTelefono = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}

