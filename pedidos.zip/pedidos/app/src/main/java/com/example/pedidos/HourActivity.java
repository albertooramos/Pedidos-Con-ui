package com.example.pedidos;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Calendar;

public class HourActivity extends AppCompatActivity {

    public static final String HORA = "send";
    public static final String DIA = "dia";
    public static final String MODO = "modo";
    private int cortado;
    private int solo;
    private int leche;
    private String dia;
    private String hora;
    TextView diaTextView;
    TextView horaTextView;
    private String modo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hour);

        diaTextView = findViewById(R.id.dia);
        horaTextView = findViewById(R.id.hora);

        final Calendar cldr = Calendar.getInstance();
        int day_now = cldr.get(Calendar.DAY_OF_MONTH);
        int month_now = cldr.get(Calendar.MONTH);
        int year_now = cldr.get(Calendar.YEAR);
        saveDay(day_now, month_now, year_now);
        diaTextView.setOnClickListener(v -> {
            DatePickerDialog picker = new DatePickerDialog(HourActivity.this,
                    (view, year, month, day) -> saveDay(day, month, year), year_now, month_now, day_now);
            picker.show();
        });

        int hour_now = cldr.get(Calendar.HOUR_OF_DAY);
        int min_now = cldr.get(Calendar.MINUTE);
        saveHour(hour_now, min_now);
        horaTextView.setOnClickListener(v -> {
            TimePickerDialog picker = new TimePickerDialog(HourActivity.this,
                    (view, hour, min) -> saveHour(hour, min), hour_now, min_now, true);
            picker.show();
        });

        Toolbar toolbar = findViewById(R.id.toolbar_order);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        cortado = intent.getIntExtra(MainActivity.CORTADO, 0);
        solo = intent.getIntExtra(MainActivity.SOLO, 0);
        leche = intent.getIntExtra(MainActivity.LECHE, 0);
    }

    private void saveHour(int hour, int min) {
        hora = min < 10 ? String.format("%d:0%d", hour, min)
                : String.format("%d:%d", hour, min);
        horaTextView.setText(hora);
    }

    private void saveDay(int day, int month, int year) {
        dia = String.format("%d/%d/%d", day, month + 1, year);
        diaTextView.setText(dia);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_order, menu);
        return true;
    }

    public void goToSend(MenuItem item) {
        if (modo == null) {
            Toast.makeText(this, "Seleccione un modo de entrega", Toast.LENGTH_LONG).show();
        } else {
            Intent intent = new Intent(this, SendActivity.class);
            intent.putExtra(MainActivity.CORTADO, cortado);
            intent.putExtra(MainActivity.SOLO, solo);
            intent.putExtra(MainActivity.LECHE, leche);
            intent.putExtra(HORA, hora);
            intent.putExtra(DIA, dia);
            intent.putExtra(MODO, modo);
            startActivity(intent);
        }
    }

    public void radiobuttonClicked(View view) {
        if (((RadioButton) view).isChecked()) {
            switch(view.getId()) {
                case R.id.domicilio:
                    modo = "A domicilio";
                    break;
                case R.id.local:
                    modo = "En local";
                    break;
            }
        }

    }
}