package com.example.pedidos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView showSolo;
    int counterS = 0;
    TextView showLeche;
    int counterL = 0;
    TextView showCortado;
    int counterC = 0;


    public void soloIn(View view) {
        counterS++;
        showSolo.setText(Integer.toString(counterS));
    }

    public void soloDe(View v) {
        counterS = Math.max(0, --counterS);
        showSolo.setText(Integer.toString(counterS));
    }

    public void lecheIn(View view) {
        counterL++;
        showLeche.setText(Integer.toString(counterL));
    }

    public void lecheDe(View v) {
        counterL = Math.max(0, --counterL);
        showLeche.setText(Integer.toString(counterL));
    }

    public void cortadoIn(View view) {
        counterC++;
        showCortado.setText(Integer.toString(counterC));
    }

    public void cortadoDe(View v) {
        counterC = Math.max(0, --counterC);
        showCortado.setText(Integer.toString(counterC));
    }

    public static final String CORTADO = "cortado";
    public static final String SOLO = "solo";
    public static final String LECHE = "leche";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        showSolo = findViewById(R.id.counterSolo);
        showLeche = findViewById(R.id.counterLeche);
        showCortado = findViewById(R.id.counterCortado);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void goToOrder(MenuItem item) {
        Intent intent = new Intent(this, HourActivity.class);
        intent.putExtra(CORTADO, counterC);
        intent.putExtra(SOLO, counterS);
        intent.putExtra(LECHE, counterL);
        startActivity(intent);
    }
}